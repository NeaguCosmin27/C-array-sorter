#include <iostream>

using namespace std;

int main()
{
    int array[] = { 1, 3, 5, 4, 7, 2, 0 , 10, 6, 21, 18, 12, 11, 25, 41, 50, 42, 8};

    cout << "Initial array: " << endl;
    for (int i = 0; i < sizeof(array) / sizeof(int); i++) {
        cout << array[i] << " " << flush;
    }

    cout << endl;

    cout << "Ascending array: " << endl;

    //Sort ascending
    for (int i = 0; i < sizeof(array) / sizeof(int); i++) {
        //cout << array[i] << " " << flush;

        for (int j = 0; j < sizeof(array) / sizeof(int); j++) {

            if(array[j] > array[i]) {

                int* firstElement = &array[j];
                int* secondElement = &array[i];

                int firstNumberSave = *firstElement;
                *firstElement = *secondElement;
                *secondElement = firstNumberSave;

            }
            else if (array[j] == array[i]) {

            }

        }
    }

    for (int i = 0; i < sizeof(array) / sizeof(int); i++) {
        cout << array[i] << " " << flush;
    }

    cout << endl;

    cout << "Descending array: " << endl;

    //Sort descending
    for (int i = 0; i < sizeof(array) / sizeof(int); i++) {
        //cout << array[i] << " " << flush;

        for (int j = 0; j < sizeof(array) / sizeof(int); j++) {

            if (array[j] < array[i]) {

                int* firstElement = &array[j];
                int* secondElement = &array[i];

                int firstNumberSave = *firstElement;
                *firstElement = *secondElement;
                *secondElement = firstNumberSave;

            }
            else if (array[j] == array[i]) {

            }

        }
    }

    for (int i = 0; i < sizeof(array) / sizeof(int); i++) {
        cout << array[i] << " " << flush;
    }

    cout << endl;

    return 0;
}


